#ifndef __RTL8721D_RegConfig_RAM_H__
#define __RTL8721D_RegConfig_RAM_H__


/*--------------------Define --------------------------------------------*/

/*--------------------Define Enum---------------------------------------*/

/*--------------------Define MACRO--------------------------------------*/

/*--------------------Define Struct---------------------------------------*/

/*--------------------Export global variable-------------------------------*/

/*--------------------Function declaration---------------------------------*/
extern void
config_agc_tab_8721D(
	void
);

extern void
config_phy_reg_8721D(
	void
);

extern void
config_mac_reg_8721D(
	void
);

extern void
config_rfc_reg_8721D(
	void
);


#endif  //__RTL8721D_RegConfig_RAM_H__


