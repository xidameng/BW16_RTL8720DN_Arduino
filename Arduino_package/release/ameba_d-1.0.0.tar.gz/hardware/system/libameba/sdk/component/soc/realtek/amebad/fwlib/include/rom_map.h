/**
  ******************************************************************************
  * @file    rom_map.h
  * @author
  * @version V1.0.0
  * @date    2016-05-17
  * @brief   This file contains all the definations of rom map.
  ******************************************************************************
  * @attention
  *
  * This module is a confidential and proprietary property of RealTek and
  * possession or use of this module requires written permission of RealTek.
  *
  * Copyright(c) 2016, Realtek Semiconductor Corporation. All rights reserved.
  ****************************************************************************** 
  */
#ifndef _ROM_MAP_
#define _ROM_MAP_

#endif //_ROM_MAP_
/******************* (C) COPYRIGHT 2016 Realtek Semiconductor *****END OF FILE****/
