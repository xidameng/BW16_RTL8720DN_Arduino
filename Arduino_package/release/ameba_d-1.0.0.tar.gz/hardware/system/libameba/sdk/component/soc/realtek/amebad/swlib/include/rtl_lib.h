#ifndef _RTL_LIB_H_
#define	_RTL_LIB_H_

#include "memproc.h"
#include "strproc.h"
#include "diag.h"

#endif /* _RTL_LIB_H_ */
