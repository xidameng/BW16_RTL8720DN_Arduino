#ifndef _RTL8721D_UART_TEST_H_
#define _RTL8721D_UART_TEST_H_
#include "hal_uart_test.h"


#endif
