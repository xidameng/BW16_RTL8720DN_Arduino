
#ifndef GRAD_MENU_H
#define GRAD_MENU_H

#include "rt_gui_demo_includes.h"
#include "start_menu.h"

#define CUS_GRAD_RET_BTN_OFFSET	CUS_TEMPRE_RET_BTN_OFFSET


void GradMenuCusPro(RT_CUS_DEMO_STS_TYPE * Sts);

#endif /* LCDCONF_H */

	 	 			 		    	 				 	  			   	 	 	 	 	 	  	  	      	   		 	 	 		  		  	 		 	  	  			     			       	   	 			  		    	 	     	 				  	 					 	 			   	  	  			 				 		 	 	 			     			 
