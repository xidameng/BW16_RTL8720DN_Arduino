#ifndef __INC_RTL8721D_SYS_ON_BIT_H
#define __INC_RTL8721D_SYS_ON_BIT_H


//================= SYSON Register Address Definition =====================//
#define REG_SYS_NORESET_FF					0x0138


#endif //__INC_RTL8721D_SYS_ON_BIT_H