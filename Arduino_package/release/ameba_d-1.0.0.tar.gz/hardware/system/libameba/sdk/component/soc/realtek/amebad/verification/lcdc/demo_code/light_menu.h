#ifndef LIGHT_MENU_H
#define LIGHT_MENU_H

#include "rt_gui_demo_includes.h"
//#include "start_menu.h"

#define u8 unsigned char
#define u16 unsigned short
#define u32 unsigned int
#define s32 signed int

#define CUS_LIGHT_RET_BTN_OFFSET	CUS_CLOCK_RET_BTN_OFFSET


#endif /* LCDCONF_H */

	 	 			 		    	 				 	  			   	 	 	 	 	 	  	  	      	   		 	 	 		  		  	 		 	  	  			     			       	   	 			  		    	 	     	 				  	 					 	 			   	  	  			 				 		 	 	 			     			 
