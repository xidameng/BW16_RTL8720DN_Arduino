#ifndef PICTURE_INC_H
#define PICTURE_INC_H

#include "GUI.h"

extern GUI_CONST_STORAGE GUI_BITMAP bmclock_pic;
extern GUI_CONST_STORAGE GUI_BITMAP bmtempre_pic;
extern GUI_CONST_STORAGE GUI_BITMAP bmgradienter_pic;
extern GUI_CONST_STORAGE GUI_BITMAP bmwave_pic;
extern GUI_CONST_STORAGE GUI_BITMAP bmlight_pic;
extern GUI_CONST_STORAGE GUI_BITMAP bmrealtek_logo;
extern GUI_CONST_STORAGE GUI_BITMAP bmreturn_btn_pic;
extern GUI_CONST_STORAGE GUI_BITMAP bmlight_off_pic;
extern GUI_CONST_STORAGE GUI_BITMAP bmlight_on_pic;
extern const GUI_FONT GUI_FontHZ_rt_demo_chs_font;

#endif /* LCDCONF_H */

	 	 			 		    	 				 	  			   	 	 	 	 	 	  	  	      	   		 	 	 		  		  	 		 	  	  			     			       	   	 			  		    	 	     	 				  	 					 	 			   	  	  			 				 		 	 	 			     			 
		    	 				 	  			   	 	 	 	 	 	  	  	      	   		 	 	 		  		  	 		 	  	  			     			       	   	 			  		    	 	     	 				  	 					 	 			   	  	  			 				 		 	 	 			     			 
