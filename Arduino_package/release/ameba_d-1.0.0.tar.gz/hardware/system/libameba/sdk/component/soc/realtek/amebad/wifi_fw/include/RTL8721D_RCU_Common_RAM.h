#ifndef __RTL8721D_RCU_COMMON_RAM_H__
#define __RTL8721D_RCU_COMMON_RAM_H__

//#include "RTL8721D_INT_RAM.h"
#include "RTL8721D_Packet_RAM.h"
//#include "RTL8721D_TxReport_RAM.h"
//#include "RTL8721D_Util_RAM.h"
//#include "RTL8721D_IOPath.h"
#include "RTL8721D_GPIO_RAM.h"
#include "RTL8721D_RCU_PhyCfg_RAM.h"

#if 0
#include "HALCom_PhyCfg_RAM.h"
#include "HALCom_PhyReg_RAM.h"
#include "HALCom_Reg_RAM.h"
#include "HALCom_initial_offload_RAM.h"
#include "HALCom_IOPath_RAM.h"
#endif


#endif //#ifndef __RTL8721D_RCU_COMMON_RAM_H__

