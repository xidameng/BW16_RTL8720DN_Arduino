/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2013 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */


#ifndef __HAL_CRYPTO_H__
#define __HAL_CRYPTO_H__

#include "ameba_soc.h"
#include "basic_types.h"

#endif /* __HAL_CRYPTO_H__ */

