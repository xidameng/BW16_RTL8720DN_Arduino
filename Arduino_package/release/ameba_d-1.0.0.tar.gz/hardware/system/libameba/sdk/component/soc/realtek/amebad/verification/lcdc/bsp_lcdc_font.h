#ifndef __BSP_LCDC_FONT_H
#define __BSP_LCDC_FONT_H 	

extern const unsigned char asc2_1206[][12];
extern const unsigned char asc2_1608[][16];
extern const unsigned char asc2_2412[][36];
extern const unsigned char asc2_3216[][64];

//#define LCDC_FPGA_VERIFY     1

#endif
