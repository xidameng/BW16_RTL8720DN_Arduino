#ifndef REALTEK_DEMO_H
#define REALTEK_DEMO_H

#include "rt_gui_demo_includes.h"

extern RT_CUS_DEMO_STS_TYPE  RtCusDemoVar;

void RealtekDemo(void) ;

#endif /* LCDCONF_H */

	 	 			 		    	 				 	  			   	 	 	 	 	 	  	  	      	   		 	 	 		  		  	 		 	  	  			     			       	   	 			  		    	 	     	 				  	 					 	 			   	  	  			 				 		 	 	 			     			 
