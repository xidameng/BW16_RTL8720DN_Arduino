/*
 *  Routines to access hardware
 *
 *  Copyright (c) 2013 Realtek Semiconductor Corp.
 *
 *  This module is a confidential and proprietary property of RealTek and
 *  possession or use of this module requires written permission of RealTek.
 */

extern u32 rand_seed[4]; //z1, z2, z3, z4, 
extern u32 rand_first;

u32
Rand (
 VOID
);


