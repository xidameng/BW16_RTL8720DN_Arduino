#ifndef __RTL8192F_ROM_TEST_H__
#define __RTL8192F_ROM_TEST_H__

#ifndef __ASSEMBLY__
extern void
RomTest(
    IN const char *argv[]
)MEMMDL_LARGE;
#endif

#endif      //#ifndef __RTL8192F_ROM_TEST_H__
