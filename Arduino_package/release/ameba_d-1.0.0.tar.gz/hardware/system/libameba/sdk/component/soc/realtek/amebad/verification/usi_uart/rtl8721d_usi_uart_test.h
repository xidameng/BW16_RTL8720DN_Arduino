#ifndef _RTL8721D_LCDC_TEST_H_
#define _RTL8721D_LCDC_TEST_H_

#define LCDC_TEST_CNT    1000

#endif
