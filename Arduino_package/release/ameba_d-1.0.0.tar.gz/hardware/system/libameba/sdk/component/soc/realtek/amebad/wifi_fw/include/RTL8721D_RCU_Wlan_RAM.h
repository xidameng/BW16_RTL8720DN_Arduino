#ifndef __RCU_WLAN_RAM_H__
#define __RCU_WLAN_RAM_H__

#include "RTL8721D_RCU_Init_RAM.h"
#include "RTL8721D_MLME_RAM.h"
#include "RTL8721D_PowerSave_RAM.h"
#include "RTL8721D_RCU_WoWLAN_RAM.h"
#include "RTL8721D_Wifi.h"
#include "RTL8721D_RCU_Task_RAM.h"
#include "RTL8721D_RCU_Normal_Dbg.h"

/*--------------------Define --------------------------------------------*/

/*--------------------Define Enum---------------------------------------*/

/*--------------------Define MACRO--------------------------------------*/

/*--------------------Define Struct---------------------------------------*/

/*--------------------Export global variable-------------------------------*/

/*--------------------Function declaration---------------------------------*/


#endif  //__WLAN_RAM_H__

