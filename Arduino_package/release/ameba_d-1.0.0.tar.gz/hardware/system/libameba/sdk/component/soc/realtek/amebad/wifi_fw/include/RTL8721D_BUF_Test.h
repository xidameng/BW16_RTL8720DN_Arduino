#ifndef __RTL8192F_BUF_TEST_H__
#define __RTL8192F_BUF_TEST_H__

extern void BufTest(
    const char *argv[]
)MEMMDL_LARGE;

#endif  //#ifndef __RTL8192F_REG_TEST_H__

