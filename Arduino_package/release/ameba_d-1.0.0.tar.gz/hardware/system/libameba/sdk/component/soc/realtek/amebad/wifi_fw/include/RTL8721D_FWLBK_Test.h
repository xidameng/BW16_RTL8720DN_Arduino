#ifndef __RTL8721D_FWLBK_TEST_H__
#define __RTL8721D_FWLBK_TEST_H__

extern void
FwLbkTest(
    IN const char *argv[]
)MEMMDL_LARGE;

#endif      //#ifndef __RTL8192F_DDMA_TEST_H__