#ifndef __RTL8721D_RCU_OS_SIG_RAM_H__
#define __RTL8721D_RCU_OS_SIG_RAM_H__
extern void
SendSignalCommon_8721D(
    u8  event
);

extern void
OSSendSignalCommon_8721D(
    u8  event
); 
#endif
